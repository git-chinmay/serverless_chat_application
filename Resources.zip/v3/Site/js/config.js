var ChatApp = window.ChatApp || {};

ChatApp.apiEndpoint = '<your API endpoint>';